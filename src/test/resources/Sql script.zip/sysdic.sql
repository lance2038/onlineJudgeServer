/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:09:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `sysdic`
-- ----------------------------
DROP TABLE IF EXISTS `sysdic`;
CREATE TABLE `sysdic` (
  `dic_name` longtext,
  `dic_value` int(11) NOT NULL,
  `dic_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`dic_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sysdic
-- ----------------------------
INSERT INTO `sysdic` VALUES ('java', '1', '1');
INSERT INTO `sysdic` VALUES ('android', '2', '1');
