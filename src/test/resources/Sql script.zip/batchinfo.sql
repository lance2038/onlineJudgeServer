/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:12:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `batchinfo`
-- ----------------------------
DROP TABLE IF EXISTS `batchinfo`;
CREATE TABLE `batchinfo` (
  `descinfo` varchar(500) DEFAULT NULL,
  `buycount` int(11) DEFAULT '0',
  `batchid` varchar(32) NOT NULL,
  `ownid` varchar(32) NOT NULL,
  `price` double(18,2) DEFAULT '0.00',
  `title` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`batchid`),
  UNIQUE KEY `currentinfo_uuid_uindex` (`batchid`),
  KEY `currentinfo_ownId_index` (`ownid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of batchinfo
-- ----------------------------
INSERT INTO `batchinfo` VALUES ('111111111', '0', '62457d6718bc4880bc949467c7cf9508', '3c6e346e5b2111e8b2e50090f5d28238', '3.20', '1111');
