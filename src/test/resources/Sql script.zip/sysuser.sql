/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:10:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `sysuser`
-- ----------------------------
DROP TABLE IF EXISTS `sysuser`;
CREATE TABLE `sysuser` (
  `usr_id` varchar(32) NOT NULL,
  `usr_code` varchar(32) NOT NULL,
  `usr_name` varchar(500) DEFAULT NULL,
  `usr_passwd` varchar(32) DEFAULT NULL,
  `usr_type` int(11) DEFAULT NULL,
  `usr_flag` int(11) DEFAULT '1',
  `usr_black` int(11) DEFAULT '0',
  `usr_mail` varchar(500) DEFAULT NULL,
  `usr_phone` varchar(500) DEFAULT NULL,
  `usr_mark` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`usr_code`),
  UNIQUE KEY `sysuser_usr_id_uindex` (`usr_id`),
  UNIQUE KEY `SysUser_usr_code_uindex` (`usr_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sysuser
-- ----------------------------
INSERT INTO `sysuser` VALUES ('11', '0d7e6bfe5b2211e8b2e50090f5d28238', '1', '6512BD43D9CAA6E02C990B0A82652DCA', '1', '1', '0', '11@11', null, null);
INSERT INTO `sysuser` VALUES ('111', '2631a9405b2211e8b2e50090f5d28238', '11', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '1@1', null, null);
INSERT INTO `sysuser` VALUES ('11111111111111', '31621b6e5b2511e8b2e50090f5d28238', '1111', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '1@1', null, null);
INSERT INTO `sysuser` VALUES ('444', '355a72825b2411e8b2e50090f5d28238', '333', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '22@1', null, null);
INSERT INTO `sysuser` VALUES ('1', '3c6e346e5b2111e8b2e50090f5d28238', '1', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', null, null, null);
INSERT INTO `sysuser` VALUES ('12', '689a8ef95b2311e8b2e50090f5d28238', '1', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '1@1', null, null);
INSERT INTO `sysuser` VALUES ('2', '6a9efbde628e11e8a31d0090f5d28238', '2', 'FAF737AB95EECBC468268A7548F79DD1', '0', '1', '0', '2', null, null);
INSERT INTO `sysuser` VALUES ('hh', '95d667675b2511e8b2e50090f5d28238', 'yy', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', 'd@1', null, null);
INSERT INTO `sysuser` VALUES ('1223', 'a7a9aec65b2311e8b2e50090f5d28238', '122', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '1@1', null, null);
INSERT INTO `sysuser` VALUES ('11111', 'bddee0755b2211e8b2e50090f5d28238', '11111', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '1111@11', null, null);
INSERT INTO `sysuser` VALUES ('00', 'd89ea3f79d1911ebbcd50090f5d28238', '00', 'B4B147BC522828731F1A016BFA72C073', '1', '1', '0', '00@qq.com', null, null);
INSERT INTO `sysuser` VALUES ('111111111', 'dc81ded15b2211e8b2e50090f5d28238', '111111', 'C4CA4238A0B923820DCC509A6F75849B', '1', '1', '0', '1@1', null, null);
INSERT INTO `sysuser` VALUES ('222', 'fa4e90a55b2311e8b2e50090f5d28238', '111', '6512BD43D9CAA6E02C990B0A82652DCA', '1', '1', '0', '1@1', null, null);
