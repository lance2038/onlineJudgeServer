/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:11:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `questionclass`
-- ----------------------------
DROP TABLE IF EXISTS `questionclass`;
CREATE TABLE `questionclass` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` longtext NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of questionclass
-- ----------------------------
INSERT INTO `questionclass` VALUES ('1', '第一章 Java语言概论');
INSERT INTO `questionclass` VALUES ('2', '第二章 Java语言基础');
INSERT INTO `questionclass` VALUES ('3', '第三章 面向对象程序设计');
INSERT INTO `questionclass` VALUES ('4', '第四章 Java小应用程序');
INSERT INTO `questionclass` VALUES ('5', '第五章 异常处理');
INSERT INTO `questionclass` VALUES ('6', '第六章 图形与用户界面技术');
INSERT INTO `questionclass` VALUES ('7', '第七章 多线程');
INSERT INTO `questionclass` VALUES ('8', '第八章 多媒体编程');
INSERT INTO `questionclass` VALUES ('9', '第九章 输入与输出流');
INSERT INTO `questionclass` VALUES ('10', '第十章 网络通讯与编程');
INSERT INTO `questionclass` VALUES ('11', '第十一章 Java语言的数据库访问技术');
INSERT INTO `questionclass` VALUES ('12', '第十二章 Android软件开发');
