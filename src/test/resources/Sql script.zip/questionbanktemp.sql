/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:11:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `questionbanktemp`
-- ----------------------------
DROP TABLE IF EXISTS `questionbanktemp`;
CREATE TABLE `questionbanktemp` (
  `titleid` int(11) NOT NULL AUTO_INCREMENT,
  `classid` int(11) NOT NULL,
  `question` longtext NOT NULL,
  `opt1` longtext NOT NULL,
  `opt2` longtext NOT NULL,
  `opt3` longtext NOT NULL,
  `opt4` longtext NOT NULL,
  `answer` longtext NOT NULL,
  `explainmsg` longtext NOT NULL,
  `ownid` varchar(32) NOT NULL,
  `batchid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`titleid`),
  KEY `questionbanktemp_batchId_index` (`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of questionbanktemp
-- ----------------------------
