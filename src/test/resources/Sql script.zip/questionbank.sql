/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:10:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `questionbank`
-- ----------------------------
DROP TABLE IF EXISTS `questionbank`;
CREATE TABLE `questionbank` (
  `uuid` varchar(32) NOT NULL,
  `type` int(11) NOT NULL,
  `classid` int(11) NOT NULL,
  `question` longtext NOT NULL,
  `opt1` longtext NOT NULL,
  `opt2` longtext NOT NULL,
  `opt3` longtext NOT NULL,
  `opt4` longtext NOT NULL,
  `answer` longtext NOT NULL,
  `explainmsg` longtext NOT NULL,
  `ownid` varchar(32) NOT NULL,
  `batchid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of questionbank
-- ----------------------------
INSERT INTO `questionbank` VALUES ('1', '1', '1', '下列不属于java语言鲁棒性特点的是：', 'java能检查程序在变异和运行时的错误', 'java 能运行虚拟机实现跨平台', ' java 自己操纵内存减少了内存出错的可能性', 'java 还实现了真数组，避免了覆盖数据的可能', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('10', '1', '1', '在当前的java实现中，每个编译单元就是一个以（）为后缀的文件', 'java', ' class', 'doc', 'exe', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('100', '1', '9', '当要将一文本文件当作一个数据库访问，读完一个纪录后，跳到另一个纪录，它们在文件的不同地方时，一般使用（）类访问。', 'FileOutputStream', 'RandomAccessFile', 'PipedOutputStream', 'BufferedOutputStream', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('101', '1', '9', 'java中，实现通过网络使用URL访问对象的功能的流是（）', '　　URL输入流', 'Sock输入流', ' PipedInputStream输入流', 'BufferedInputStream输入流', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('102', '1', '11', 'Java中，JDBC是指', 'Java程序与数据库连接的一种机制', 'Java程序与浏览器交互的一种机制', 'Java类库名称', 'Java类编译程序', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('103', '1', '11', '在利用JDBC连接数据库时，为建立实际的网络连接，不必传递的参数是', ' URL', '数据库用户名', '密码', '以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('104', '1', '11', 'J2ME是为嵌入式和移动设备提供的Java平台，它的体系结构由(    )组成。', ' Profiles', 'Configuration', 'OptionalPackages', '以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('105', '1', '11', 'J2EE包括的服务功能有', '命名服务JNDI(LDAP)和事务服务JTA', ' 安全服务和部署服务', '消息服务JMS和邮件服务JavaMail', ' 以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('106', '1', '11', 'JDBC的模型对开放数据库连接(ODBC)进行了改进,它包含（）', ' 一套发出SQL语句的类和方法', '更新表的类和方法', '调用存储过程的类和方法', '以上全部都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('107', '1', '11', 'JDBC中要显式地关闭连接的命令是（）', 'Connection．close()；', 'RecordSet．close()', 'Connection．stop()', 'Connection．release()', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('108', '1', '11', 'TCP／IP系统中的端口号是一个(    )位的数字，它的范围是0到65535。', ' 8', '16', '32', '64', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('109', '1', '11', '在Java编程语言中，TCP／IPsocket连接是用java．net包中的类实现的。其连接步骤和方法是', ' 服务器分配一个端口号。如果客户请求一个连接，服务器使用accept()方法打开socket连接', '客户在host的port端口建立连接', '服务器和客户使用InputStream和OutputStream进行通信', '以上全部', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('11', '1', '2', '下列java标识符，错误的是（）', '_sys_varl', '$change', 'User_name', '1_file', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('110', '1', '11', 'J2ME中的Profile定义应用系统的(    )特性。', ' 生命周期模型', '用户界面', '访问设备', '以上全部都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('111', '1', '11', 'J2EE平台的优势不包括（）', ' “一次编程，任意运行”', '应用独立于供应商、服务器、工具，构件的选择自由', ' 跨平台的解释器作为其核心技术', '提高软件复用', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('112', '1', '8', '局域网中，广泛应用的集线器端口的街头是（  ）', 'RJ-23', 'RJ-43', 'RJ-45 ', 'RJ-32', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('113', '1', '8', '促进多媒体控制发展的关键技术，下列正确的是（       ）', 'CD-ROM存储', '压缩技术', '多媒体标准', '多媒体计算机硬件', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('114', '1', '8', '多媒体计算机的关键技术有（    ）', '视频音频信号获取技术', '视频音频数据的实时处理和特技', '多媒体数据压缩编码和解码技术', '视频音频数据的输出技术', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('115', '1', '8', '多媒体计算机在生活的各个方面都发挥了不小的作用，其应用领域的正确选项是（   ）', '商业服务，娱乐', '教育培训', '信息咨询、家教', '交互式', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('116', '1', '8', '多媒体系统中，图象和声音的信息是以（   ）的形式存储的', '数据库文件', 'WORD文件', '二进制文件', '文本文件', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('117', '1', '8', 'AVE的最核心部件是（    ）', '合成器', '数字信号处理器', '混合器', '模拟滤波器', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('118', '1', '8', '19、在Intenet上，使用的域名地址必须经域名服务器（简称DNS）将域名翻译成IP地址，才能被网络识别。根据组织性顶级域名标准，网络机构的域名是（     ）。', 'OGR', 'COM', 'NET ', 'MIL', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('119', '1', '8', '有关流媒体，以下说法正确的是（    ）', 'RTP数据传输协议未涉及质量保证和资源预订服务', 'RTP只在一对一的传输情况下工作', 'RTP数据传输协议设计质量保证和资源预定服务', 'RTP不允许监控数据传输', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('12', '1', '2', '下列不属于简单数据类型的是（）', '整数类型', '类', '符点数类型', '布尔类型', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('120', '1', '8', '、中央处理器中断请求时，中断控制逻辑会自动向CPU提供设备的地址。IRQ值08对应的硬件是（   ）', '键盘', '通讯端口（COMI）', '系统计时器', '系统CMOS实时钟', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('13', '1', '2', '下列属于JAVA关键词的是（）', 'TRUE', 'goto', 'float', 'NULL', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('14', '1', '2', '下列声明和赋值语句错误的是', 'double w=3.1415;', 'String strl=”bye”;', 'float z=6.74567', 'boolean truth=true;', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('15', '1', '2', 'java中，八进制数以______开头。', '0x', '0', '0X', '8', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('16', '1', '2', '自定义类型转换是由按优先关系从低级数据转换为高级数据，优先次序为（）', 'char-int-long-float-double', 'int-long-float-double-char', 'long-float-int-double-char', '以上都不对', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('164', '1', '10', '若对Web页面进行操作，一般会用到的类是', 'Socket', 'DatagramSocket', 'URL', 'URLConnection', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('165', '1', '10', '在套接字编程中，客户方需用到Java类（ C ）来创建TCP连接。', 'ServerSocket', 'DatagramSocket', 'Socket', 'URL', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('166', '1', '10', '在套接字编程中，服务器方需用到Java类（ ）来监听端口', 'Socket', 'URL', 'ServerSocket', 'DatagramSocket', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('167', '1', '10', 'URL类的getHost方法的作用是', '返回主机的名字', '返回网络地址的端口', '返回文件名', '返回路径名', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('168', '1', '10', 'URL类的getRef方法的作用是', '返回网页的特定地址', '返回主机的名字', '返回路径名', '返回协议的名字', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('169', '1', '10', 'Socket类的getOutputStream方法的作用是', '返回文件路径', '返回文件写出器', '返回文件大小', '返回文件读入器', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('17', '1', '2', '在java中，Integer.MAX_VALUE表示', '浮点类型最大值', '整数类型最大值', '长整型最大值', '以上说法都不对', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('170', '1', '10', 'Socket类的getInputStream方法的作用是', '返回文件路径', '返回文件写出器', '返回文件大小', '返回文件读入器', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('18', '1', '2', 'JAVA中，数据类型值中不可能出现的符号是（）', 'd', 'f', 'e', '/', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('181', '1', '6', '鼠标被移动时会调用▁▁方法，并且注册一个事件监听器处理此事件。', 'actionPerformed ', 'addItemListener', 'mouseMove ', 'add ', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('182', '1', '6', '用户不能修改的文本是', 'word 文档', 'txt 文档 ', '可编辑的', '不可编辑的', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('183', '1', '6', '▁▁用来在 Container 上排列 GUI构件', 'BorderLayout 类', 'Component 类', '事件控制', '布局管理器', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('184', '1', '6', '为添加一个构件的 add 方法是▁▁类方法', 'BorderLayout ', 'Component', 'Container', 'ButtonGroup ', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('185', '1', '6', '使用方法▁▁为构件容器设置布局管理器', 'BorderLayout', 'setLayout ', 'Container', ' Component', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('186', '1', '6', 'GUI 是▁▁的缩写', '布局管理器', '资源管理器 ', ' 用户界面布局', '图形用户界面 ', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('187', '1', '6', '当构件中按钮的位置可以被自动调整，应使用哪种布局管理器', 'BorderLayout', 'FlowLayout', 'CardLayout ', 'GridLayout ', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('188', '1', '6', '使用▁▁类创建菜单对象', 'Dimension', 'JMenu', 'JMenuItem', 'JTextArea', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('189', '1', '6', '使用▁▁方法创建菜单中的分隔条', 'setEditable ', ' ChangeListener', 'add', 'addSeparator', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('19', '1', '2', '下列表示单引号的是（）', '‘', '\\\\’', '\\\\\\\\’', '‘\\\\', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('190', '1', '6', '向 JTextArea 的▁▁方法传递 false 参数可以防止用户修改文本', 'setEditable', 'ChangeListener', 'add ', 'addSeparator', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('191', '1', '6', '下面哪个布局管理器是非法的：', ' FlowLayout', 'BorderLayout', 'CardBagLayout ', 'GridLayout', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('192', '1', '6', '实现下列哪个接口可以对 TextField 对象的事件进行监听和处理?', 'MouseMotionListener', 'FocusListener', 'ActionListener', ' WindowListener ', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('193', '1', '6', 'Frame 的默认的布局管理器是下列哪一个', 'FlowLayout', ' CardLayout', 'GridLayout', 'BorderLayout', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('194', '1', '6', '请问如下哪个方法可以将 MenuBar 加入 Frame 中? ', 'setMenu() ', 'setMenuBar()', ' add() ', 'addMenuBar() ', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('195', '1', '1', '下列说法不正确的是__________', ')Java语言不支持分布式计算', 'Java是跨平台的语言', 'Java是面向对象语言', 'Java是具有多线程并发机制的语言', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('196', '1', '1', 'Java语言的并发机制是__________。', '多线程机制', ')垃圾回收机制', '代码安全检验机制', '异常处理机制', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('197', '1', '1', 'JDK的bin目录下提供的Java调试器是__________', 'javac', 'javadoc', 'java', 'jdb', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('198', '1', '1', 'Java语句要执行一个Applet程序的命令是__________', 'appletviewer', 'java', 'javc', 'jdbc', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('199', '1', '1', '、要执行一个Java Applet程序，必须有的文件类是__________', 'XML', 'Text', 'HTML', 'GPL', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('2', '1', '1', 'java语言的执行模式是：', '全编译型', '全解释型', '半编译和半解释型', '同脚本语言的解释模式', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('20', '1', '2', '下列语句片断中，four得值为：（）\r\n　　　int three=3;\r\n　　　char one=‘1’\r\n　　　char four=(char)(three+one);', '3', '1', '31', '4', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('200', '1', '1', '一个Java源程序文件的扩展名必须是__________。', 'jar', 'class ', 'java', 'war', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('201', '1', '1', 'Java编译器产生的文件扩展名必须是__________。', 'jar', 'class', 'java', 'war', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('202', '1', '1', '下列各项中，属于软件的是__________', 'CPU ', 'ALU', 'RAM', 'JVM', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('203', '1', '1', 'Java Applet程序设计执行在_________', 'CPU上', '浏览器上 ', '服务器上', 'ROM上', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('204', '1', '1', '支持抽象窗口类型的包是__________。', 'java.lang', 'java.lang.ref', 'java.awt ', 'java.util', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('205', '1', '1', '能在命令窗口显示信息的方法是__________。', 'System.out.print() ', 'read()', 'write()', 'show', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('206', '1', '1', '应用程序结束的方法是用System类的__________。', 'end()', 'exit()', 'set()', 'get()', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('207', '1', '1', '显示消息对话框和输入对话框的类是__________。', 'JOptionPanc ', 'System', 'Dialog', 'ShowDialog', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('208', '1', '1', '装载JOptionPane类的软件包是__________', 'java.awt', 'java.net', 'java.transaction', 'java.swing', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('209', '1', '12', '“安卓”的英文名称是什么？', 'Andrew', 'Android', 'Andros', 'Atradius', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('21', '1', '2', '下列不属于整型变量的类型是', 'byte', 'short', 'float', 'long', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('210', '1', '12', '“安卓”是哪个公司主导研发的？', '诺基亚', '微软', '谷歌', '苹果', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('211', '1', '12', '“安卓”是哪一年发布的？', '2005年8月17日', '2007年11月5日', '2008年10月21日', '2006年5月1日', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('212', '1', '12', '“安卓”是以什么为基础的操作系统？', 'java', 'unix', 'windows', 'linux', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('213', '1', '12', '以下采用的是安卓系统的手机是', '海尔、HTC、摩托罗拉、诺基亚', '酷派、摩托罗拉、联想、华为', 'LG、天语、联想、苹果', '华为、诺基亚、酷派、三星', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('214', '1', '12', '哪个智能操作系统是开源的系统？', 'Symbian ', 'Android', 'Windows Phone', 'IOS', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('215', '1', '12', 'Android从哪个版本开始支持应用程序安装到SD卡上的？', 'Android 2.1', 'Android 2.2', 'Android 2.3', 'Android 2.0', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('216', '1', '12', 'RAM指的是手机的？', '运行内存', '存储内存', '手机硬盘', '内存卡', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('217', '1', '12', '智能手机的定义是', '可以任意安装卸载软件的手机', '使用智能操作系统的手机', '3G手机都是智能手机', '具有PAD功能的手机', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('218', '1', '12', '安卓系统安装的软件是什么格式的？', 'Sisx', 'java ', 'apk', 'jar', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('219', '1', '12', 'ROM指的是手机的？', '运行内存', '存储内存', '音频芯片 ', '内存卡', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('22', '1', '2', ' int类型整型变量在内存中的位数为', '8', '16', '32', '64', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('220', '1', '12', 'WIFI指的是什么？', '　　一种可以将个人电脑、手机等终端以有线方式进行相互连接的技术', '一种可以将个人电脑、手机等终端以无线方式进行相互连接的技术', '移动的无线网络', '联通的无线网络', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('221', '1', '12', '如何卸载应用程序？', '设置-应用程序-管理应用程序', '设置-应用程序-开发', '直接点住卸载', '拖到垃圾桶卸载', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('222', '1', '12', '如何从百度中下载安卓市场', '打开百度直接搜索安卓市场点击下载', '在本机搜索安卓市场进行安装', '从内存卡直接安装', '本机自带不用安装', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('223', '1', '12', '如何关闭数据开关', '设置-应用程序-未知来源', '设置-账户与同步-背景数据', '设置-无线和网络-移动网络-已启用数据', '设置-位置和安全-移动数据', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('224', '1', '12', '手机壁纸的设定正确的步骤是', '常按主屏幕，选择壁纸，设定壁纸', '进入设置，选择壁纸，设定壁纸', '进入设置，选择显示，动画设置所有动画', '常按屏幕选择小插件，设定壁纸', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('225', '1', '12', '如何开启WLAN ？', '进入设置选择无线和网络，打开移动网络', '进入设置，选择无线和网络打开飞行模式', '进入设置选择无线和网络，打开W LAN', '进入设置，选择无线和网络打开蓝牙', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('226', '1', '12', 'Android操作系统得手机下如何查看近期打开过的程序？', '点击两下HOME键', '打开设置，进入应用程序，查看最近打开的程序', '打开设置，进入应用程序，打开正在运行的服务', '常按HOME键', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('227', '1', '12', '怎么激活本机锁屏密码？', '打开程序主菜单，找到第三方密码锁插件', '打开设置，进入应用程序，选择未知源', '打开设置，进入安全，选择设置屏幕锁定', '常按手机睡眠/唤醒键，选择关机设定', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('228', '1', '12', '如何使新开封手机可以安装第三方软件？', '常按手机HOME 键', '轻点Menu 选择全部应用程序', '打开设置，选择应用程序，选择未知源', '打开设置，进入应用程序，选择USB调试', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('229', '1', '12', '如何使用PC机给手机安装软件？', '使手机连接PC，选择大容量存储，安装软件 ', '打开USB调试，使手机连接PC，打开大容量存储，安装软件', '使手机连接PC，打开USB调试，打开大容量存储，安装软件', '打开USB调试，使手机连接PC，等待PC端安装手机驱动，使用第三方安装软件给手机安装软件', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('23', '1', '2', '下列数据类型转换，必须进行强制类型转换的是', 'byte→int', 'short→long', 'float→double', 'int→char', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('230', '1', '12', '如何快速设定桌面小插件？', '常按Menu键设定小插件', '常按手机主屏幕选择桌面小插件', '在手机主菜单中常按应用程序拖拽到主屏幕', '双击小房子键自动弹出小插件', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('231', '1', '12', '怎么查看手机型号与本机系统信息？', '在拨号界面输入*#06#来查看', '拨打运营商电话通过人工服务来查看', '进入设置选择关于手机来查看', '进入设置，选择安全来查看', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('232', '1', '12', '如何关闭程序自动同步，[如自动同步天气]来帮助顾客节省流量？', '进入设置选择账户与同步关闭背景数据', '进入设置 选择隐私权然后恢复出厂设置', '在设置里选择管理应用程序，把把自动同步的程序卸载', '常按睡眠/唤醒键来重启手机', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('233', '1', '12', '设置里飞行模式起到的作用？', '可以直接关闭手机', '可以来电设置黑名单', '在不允许使用手机的环境下可以代替关机来关闭手机所有无线连接', '在不允许使用手机的环境下可以代替关机来关闭手机信号', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('234', '1', '12', '如何使用蓝牙传输文件', '进入设置，打开蓝牙', '打开下拉菜单点亮蓝牙标志', '进入设置打开蓝牙，并打开可检测性，找到要传输的机子进行配对', '直接传输文件', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('235', '1', '12', '天语W800是什么系统', '原生安卓系统', 'IOS', 'WP7', '阿里云系统', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('236', '1', '12', '设置声音里的触感的作用是什么', '增加触摸灵感度', '校正屏幕', '多任务手势', '开启关闭手机下方快捷键触摸震动', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('237', '1', '12', '怎样关闭显示SIM卡里的联系人', '拔掉SIM卡', '删掉SIM卡里的联系人', '打开联系人打开MENU，找到更多里的显示选项，去掉SIM卡显示', '拨打运营商电话，去掉联系人', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('238', '1', '12', '如何单一删除通话记录里的电话号码？', '点击一下通话记录的电话号码', '双击通讯录里的电话号码', '向左滑动', '常按电话号码', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('239', '1', '12', '如何把通讯录的电话号码保存为联系人', '常按电话号码，找到添加联系人', '点击MENU，找到保存', '单击一下电话号码', '以上方法均可', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('24', '1', '2', 'java中，用（）关键字定义常量', 'final', '#define', 'float', 'const', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('240', '1', '12', '浏览器下载的软件怎么查找', '打开下载的浏览器——屏幕菜单键——更多——下载内容——找到后点击安装', '打开下载的浏览器——屏幕Home键——更多——下载内容——找到后点击安装', '打开下载的浏览器——屏幕返回键——更多——下载内容——找到后点击安装', '打开下载的浏览器——屏幕返回键——更多——页内查找——找到后点击安装', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('241', '1', '12', '怎么从系统里关闭网络数据', '设置——无线和网络——移动网络——已启用数据', '设置——无线和网络——WLAN设置', '设置——无线和网络——蓝牙设置', '设置——无线和网络——飞行模式', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('242', '1', '12', '怎么打开无线网络', '设置——无线和网络——WLAN设置——所选网络', '设置——无线和网络——蓝牙', '设置——无线和网络——飞行模式', '设置——无线和网络——移动数据', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('243', '1', '12', '怎么调节屏幕亮度', '设置——显示——亮度——进行调节', '设置——翻转设置——亮度——进行调节', '设置——应用程序——亮度——进行调节', '设置——位置和安全——亮度——进行调节', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('244', '1', '12', '手机设置密码', '设置——位置和安全——设置屏幕锁定', '设置——设置密码', '设置——设置密码——设置屏幕锁定', '设置——显示', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('245', '1', '12', '怎么结束应用程序', '设置——应用程序——管理应用程序——正在运行的服务——找到点击结束', '直接按屏幕下方主菜单键', '直接按屏幕下方返回键', '打开另一个程序', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('246', '1', '12', '怎么还原出厂设置', '设置——铺助功能', '设置——隐私权', '设置——关于手机', '设置——应用程序', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('247', '1', '12', '如果手机锁屏时WIFI就断开连接，那么怎么调成不让其断开', '不可能', '设置——无线和网络——WLAN设置——左下角菜单键——高级——WLAN休眠策略——永不休眠', '网络问题，换个网络就行', '设置——无线网络——WLAN设置——左下角菜单键——高级——WLAN休眠策略——屏幕关闭时休眠', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('248', '1', '12', '怎么新建文件夹', '按住主屏幕3秒——窗口小部件', '按住主屏幕3秒——文件夹——新建文件夹', '按住主屏幕3秒——快捷方式', '按住主屏幕3秒——壁纸', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('249', '1', '12', '怎么从SIM卡和SD卡里导入电话本', '联系人——左下角菜单键——导入导出', '通讯录——左下角菜单键——导入导出', '联系人——屏幕下角HOM键——导入导出', '通讯录——屏幕下角HOM键——导入导出', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('25', '1', '10', 'DatagramSocket类的receive方法的作用是', '根据网络地址接收数据包', '根据网络地址与端口接收数据包', '根据端口接收数据包 ', '根据网络地址与端口发送数据包', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('26', '1', '2', '关于变量的作用范围，下列说法错误的是', '异常处理参数作用域为整个类', '局部变量作用于声明该变量的方法代码段', '类变量作用于声明该变量的类', '方法参数作用于传递到方法内代码段', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('27', '1', '2', '下列属于条件运算符的是', '+', '?:', '&&', '>> ', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('276', '1', '12', '在一个实现共享首选项的 Android 应用程序中使用了 getPreferences() 方法。为什么使要用此方法？', 'getPreferences() 方法用于活动级别首选项，用于活动只需一个首选项文件的情况', 'getPreferences() 方法用于应用程序级别首选项，用于活动只需一个首选项文件的情况。', 'getPreferences() 方法用于应用程序级别首选项，用于应用程序使用多个按名称标识的首选项文件。', 'getPreferences() 方法用于活动级别首选项，用于应用程序使用多个按名称标识的首选项文件', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('277', '1', '12', '在一个移动订票应用程序中，运行应用程序时，如果单击“提交”按钮，该应用程序会抛出一个空指针异常。导致此错误的原因可能是什么？', '未在活动类中初始化按钮对象。', '未在 UI XML 文件中创建按钮。', '未调用该按钮的 onClick() 方法', '未为该按钮创建单击侦听器。', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('278', '1', '12', 'Android 中的 ______ 类提供关于绘制符号、文本和图形的样式和颜色的信息。', 'Canvas', 'Bitmap', ' Paint', 'View', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('279', '1', '12', '为了访问 Android 电话 API，需要创建 ___________ 类的实例。', 'android.telephony.PhoneStateListener ', 'android.telephony.TelephonyManager ', 'telephony.TelephonyManager', 'android.TelephonyManager ', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('28', '1', '2', '下列数组定义及赋值，错误的是', 'int intArray[];', 'intArray=new int[3];\r\nintArray[1]=1;\r\nintArray[2]=2;\r\nintArray=new int[3];\r\nintArray[1]=1;\r\nintArray[2]=2;\r\nintArray[3]=3;', 'int a[]={1,2,3,4,5};', 'int[][]=new int[2][];\r\na[0]=new int[3];\r\na[1]=new int[3];', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('280', '1', '12', '以下哪个 Android 平台支持 API 8 级？', '2.0', ' 2.1 ', '2.2 ', '2.3 ', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('281', '1', '12', '在一个UI 程序中包含文本视图和编辑文本，放置方式是一个放在另一个的下面。创建此类 UI 需要使用以下哪个布局和属性组合？', '相对布局，并且 android:orientation 属性设置为“horizontal”。', '线性布局，并且 android:orientation 属性设置为“vertical”。', '相对布局，并且 android:orientation 属性设置为“vertical”。', '线性布局，并且 android:orientation 属性设置为“horizontal”。', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('282', '1', '12', '以下哪个选项正确地以严重性降序显示严重性级别？', '1.错误\r\n2.警告\r\n3.详细消息\r\n4.调试消息\r\n5.参考消息\r\n1.错误\r\n2.警告\r\n3.详细消息\r\n4.调试消息\r\n5.参考消息\r\n1.错误\r\n2.警告\r\n3.详细消息\r\n4.调试消息\r\n5.参考消息\r\n1.错误\r\n2.警告\r\n3.详细消息\r\n4.调试消息\r\n5.参考消息\r\n', '1.错误\r\n2.警告\r\n3.参考消息\r\n4.调试消息\r\n5.详细消息', '1.警告\r\n2.参考消息\r\n3.错误\r\n4.调试消息\r\n5.详细消息', '1.参考消息\r\n2.调试消息\r\n3.详细消息\r\n4.警告\r\n5.错误', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('283', '1', '12', '以下哪项使您能够提供诸如纬度、经度和海拔之类的数据，您可以使用这些数据在模拟器中置入的启用了 LBS 的应用程序中模拟位置？', '全球定位系统 (GPS)', '传感器模拟器', '公共无线保真 (Wi-Fi) 热点', '地理编码器 (Geocoder)', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('284', '1', '12', '要从 URL 类指定的资源读取数据，需要创建哪个类的引用？', 'URLConnection 类', 'SharedPreferences 类', 'Context 类', 'FileOutputStream 类', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('285', '1', '12', '启动活动时将调用哪个生命周期方法？', 'onCreate()', 'onStart()', 'onRestart()', 'onResume() ', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('286', '1', '12', '关于 DDMS 透视图，以下哪个选项不正确？', '它使您能够跳过/跳进方法调用。', '它使您能够模拟电话和消息传递。', '它使您能够为位置设置提供值。', '它提供用于为调试选择各个过程的工具。', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('287', '1', '12', '以下哪项是有序广播？', 'ACTION_NEW_OUTGOING_CALL ', 'ACTION_BATTERY_LOW', 'ACTION_TIMEZONE_CHANGED', 'ACTION_SHUTDOWN', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('288', '1', '12', '为了在Android 设备创建媒体播放器应用程序，将现有样式应用到应用程序。下述哪一项可用于完成此任务的标记语言。', '<style name=\"Mystyle\" parent=\"@android:style/TextAppearance\">\r\n<item name=\"android:Color\"> #909000 </item>\r\n</style>', '<style name=\"Mystyle\" parent=\"@android:style/TextAppearance\">\r\n<item name=\"android:textColor\"> #909000 </item>\r\n</style>', '<style name=\"Mystyle\" parent=\"@android:style/TextAppearance\">\r\n<item name=\"android:fontColor\"> #909000 </item>\r\n</style>', '<style name=\"Mystyle\"\r\nstyleParent=\"@android:style/TextAppearance\">\r\n<item name=\"android:textColor\"> #909000 </item>\r\n</style>', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('289', '1', '12', '执行一个闹钟应用程序时，应用程序不提供所需输出。因此想用记录消息以检查活动的状态。以下哪个方法最为合适？', 'Log.v() 方法最适用于检索应用程序状态。', 'Log.d() 方法最适用于检索应用程序状态。', 'Log.e() 方法最适用于检索应用程序状态。', 'Log.i() 方法最适用于检索应用程序状态。', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('29', '1', '2', '在java中，字符串由java.lang.String和（）定义', 'java.lang.StringChar', 'java.lang.StringBuffer', 'java.io.StringChar', ' java.io.StringBuffer', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('290', '1', '12', '为了在一个基于选项卡的应用程序创建了一个 UI 资源。以下哪个选项表示选项卡的正确 XML 标记代码？', '<TabHost android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<LinearLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<TabWidget android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"wrap_content\"></TabWidget>\r\n</LinearLayout>\r\n</TabHost>', '<TabHost xmlns:android=\"http://schemas.android.com/apk/res/android\"\r\nandroid:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<LinearLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<TabWidget android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"wrap_content\"></TabWidget>\r\n<FrameLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n</FrameLayout>\r\n</LinearLayout>\r\n</TabHost>', '<LinearLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<TabWidget android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"wrap_content\"></TabWidget>\r\n<FrameLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n</FrameLayout>\r\n</LinearLayout>', '<TabHost xmlns:android=\"http://schemas.android.com/apk/res/android\"\r\nandroid:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<LinearLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n<FrameLayout android:layout_width=\"match_parent\"\r\nandroid:layout_height=\"match_parent\">\r\n</FrameLayout>\r\n</LinearLayout>\r\n</TabHost>', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('291', '1', '12', '分析以下代码并指出其目的：\r\npublic static final String MY_EVENT =\r\n\"com.broadcast.demo.action.NEW_BROADCAST_EVT\";\r\nIntent i = new Intent(MY_EVENT);\r\ni.putExtra(\"eventName\", eventType);\r\nsendBroadcast(i);', '给定代码段的目的是侦听广播事件。', '给定代码段的目的是使用意向广播事件。', '给定代码段的目的是创建广播接收器。', '给定代码段的目的是创建意向。', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('292', '1', '12', '识别声明 URI 的正确语法，该 URI 将允许您获取特定位置提供的单条记录。', '<package name>.provider.<custom content provider>/<table name>/<position>', 'content://<package name><custom content provider>/<table name>/<position>', 'content://<package name>.provider.<custom content provider>/<table name>/<position>', 'content://<package name>provider<custom content provider>/<table name>/<position>', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('293', '1', '12', '为 Android 设备创建虚拟键盘应用程序而使用了 Button窗口小部件创建键盘，可以对键盘添加滑动功能，这使得应用程序用户只需将手\r\n指在按钮上面滑动就能输入文字。当用户的手指在按钮上移动时，将自动按下按钮。为了启用此功能，应该在按钮上使用了事件处理。下述哪项是跟\r\n踪用户在按钮上滑动时被按下的按钮而可能使用的方法。', 'onKeyDown() ', ' onFocusChange()', 'onTouchEvent()', 'onTrackballEvent()', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('294', '1', '12', '提醒对话框可以显示多少个按钮？', '4', '3', '2', '1', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('295', '1', '12', '识别以下代码中的错误类型：\r\nProgressDialog pdialog = new ProgressDialog(myActivityContext);\r\npdialog.ProgressStyleset(ProgressDialog.STYLE_HORIZONTAL);', '编译时错误', '运行时错误 ', '逻辑错误', '无错误', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('296', '1', '12', '在一个应用程序中创建了 Activity 类并实现了 OnClickListener 接口以侦听Click 事件。需要重写哪个方法以侦听视图上的 Click 事件？', 'onTouch()', 'onViewClick() ', 'onClick()', 'onLongClick()', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('297', '2', '1', '一个\".java\"源文件中是否可以包括多个类（不是内部类）？有什么限制？', '0', '0', '0', '0', '　　可以有多个类，但只能有一个public的类，并且public的类名必须与文件名相一致。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('298', '2', '1', 'Java有没有goto? ', '0', '0', '0', '0', 'java中的保留字，现在没有在java中使用。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('299', '2', '1', '说说&和&&的区别。', '0', '0', '0', '0', '　　&和&&都可以用作逻辑与的运算符，表示逻辑与（and），当运算符两边的表达式的结果都为true时，整个运算结果才为true，否则，只要有一方为false，则结果为false。\r\n　　&&还具有短路的功能，即如果第一个表达式为false，则不再计算第二个表达式，例如，对于if(str != null && !str.equals(“”))表达式，当str为null时，后面的表达式不会执行，所以不会出现NullPointerException如果将&&改为&，则会抛出NullPointerException异常。If(x==33 & ++y>0) y会增长，If(x==33 && ++y>0)不会增长\r\n&还可以用作位运算符，当&操作符两边的表达式不是boolean类型时，&表示按位与操作，我们通常使用0x0f来与一个整数进行&运算，来获取该整数的最低4个bit位，例如，0x31 & 0x0f的结果为0x01。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('3', '1', '1', '下列关于虚拟机说法错误的是：', '虚拟机可以用软件实现', '虚拟机部可以用硬件实现', '字节码是虚拟机的机器码', '虚拟机把代码程序与各操作系统和硬件分开', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('30', '1', '2', '关于while和do－while循环，下列说法正确的是', '两种循环除了格式不通外，功能完全相同', '与do－while语句不通的是，while语句的循环至少执行一次', 'do-while语句首先计算终止条件，当条件满足时，才去执行循环体中的语句', '以上都不对。', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('300', '2', '1', 'switch语句能否作用在byte上，能否作用在long上，能否作用在String上?', '0', '0', '0', '0', '在switch（expr1）中，expr1只能是一个整数表达式或者枚举常量（更大字体），整数表达式可以是int基本类型或Integer包装类型，由于，byte,short,char都可以隐含转换为int，所以，这些类型以及这些类型的包装类型也是可以的。显然，long和String类型都不符合switch的语法规定，并且不能被隐式转换成int类型，所以，它们不能作用于swtich语句中。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('301', '2', '1', 'short s1 = 1; s1 = s1 + 1;有什么错? short s1 = 1; s1 += 1;有什么错? ', '0', '0', '0', '0', '　　对于short s1 = 1; s1 = s1 + 1; 由于s1+1运算时会自动提升表达式的类型，所以结果是int型，再赋值给short类型s1时，编译器将报告需要强制转换类型的错误。\r\n对于short s1 = 1; s1 += 1;由于 += 是java语言规定的运算符，java编译器会对它进行特殊处理，因此可以正确编译。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('302', '2', '1', 'char型变量中能不能存贮一个中文汉字?为什么?', '0', '0', '0', '0', '　　char型变量是用来存储Unicode编码的字符的，unicode编码字符集中包含了汉字，所以，char型变量中当然可以存储汉字啦。不过，如果某个特殊的汉字没有被包含在unicode编码字符集中，那么，这个char型变量中就不能存储这个特殊汉字。补充说明：unicode编码占用两个字节，所以，char类型的变量也是占用两个字节。\r\n备注：后面一部分回答虽然不是在正面回答题目，但是，为了展现自己的学识和表现自己对问题理解的透彻深入，可以回答一些相关的知识，做到知无不言，言无不尽。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('303', '2', '1', '用最有效率的方法算出2乘以8等於几?', '0', '0', '0', '0', '　　2 << 3，\r\n　　因为将一个数左移n位，就相当于乘以了2的n次方，那么，一个数乘以8只要将其左移3位即可，而位运算cpu直接支持的，效率最高，所以，2乘以8等於几的最效率的方法是2 << 3。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('304', '2', '1', '是否可以从一个static方法内部发出对非static方法的调用？', '0', '0', '0', '0', '　　不可以。因为非static方法是要与对象关联在一起的，必须创建一个对象后，才可以在该对象上进行方法调用，而static方法调用时不需要创建对象，可以直接调用。也就是说，当一个static方法被调用时，可能还没有创建任何实例对象，如果从一个static方法中发出对非static方法的调用，那个非static方法是关联到哪个对象上的呢？这个逻辑无法成立，所以，一个static方法内部发出对非static方法的调用。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('305', '2', '1', 'Math.round(11.5)等於多少? Math.round(-11.5)等於多少?', '0', '0', '0', '0', '　　Math类中提供了三个与取整有关的方法：ceil、floor、round，这些方法的作用与它们的英文名称的含义相对应，例如，ceil的英文意义是天花板，该方法就表示向上取整，Math.ceil(11.3)的结果为12,Math.ceil(-11.3)的结果是-11；floor的英文意义是地板，该方法就表示向下取整，Math.ceil(11.6)的结果为11,Math.ceil(-11.6)的结果是-12；最难掌握的是round方法，它表示“四舍五入”，算法为Math.floor(x+0.5)，即将原来的数字加上0.5后再向下取整，所以，Math.round(11.5)的结果为12，Math.round(-11.5)的结果为-11。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('306', '2', '1', '构造器Constructor是否可被override? ', '0', '0', '0', '0', '      构造器Constructor不能被继承，因此不能重写Override，但可以被重载Overload。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('307', '2', '1', '接口是否可继承接口? 抽象类是否可实现(implements)接口? 抽象类是否可继承具体类(concrete class)? 抽象类中是否可以有静态的main方法？', '0', '0', '0', '0', '      接口可以继承接口。抽象类可以实现(implements)接口，抽象类是否可继承具体类。抽象类中可以有静态的main方法。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('308', '2', '1', '写clone()方法时，通常都有一行代码，是什么？', '0', '0', '0', '0', '      clone 有缺省行为，super.clone();因为首先要把父类中的成员复制到位，然后才是复制自己的成员。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('309', '2', '1', 'java中实现多态的机制是什么？', '0', '0', '0', '0', '      靠的是父类或接口定义的引用变量可以指向子类或具体实现类的实例对象，而程序调用的方法在运行期才动态绑定，就是引用变量所指向的具体实例对象的方法，也就是内存里正在运行的那个对象的方法，而不是引用变量的类型中定义的方法。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('311', '2', '12', '简述R.java和AndroidManefiest.xml文件的用途', '0', '0', '0', '0', '      R.java文件是ADT自动生成的文件包含对drawable、layout和values目录内的资源的引用指针Android程序能够直接通过R类引用目录中的资源。AndroidManifest.xml是XML格式的Android程序声明文件包含了Android系统运行Android程序前所必须掌握的重要信息这些信息包括应用程序名称、图标、包名称、模块组成、授权和SDK最低版本等而且每个Android程序必须在根目录下包含一个AndroidManifest.xml文件', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('312', '2', '12', '简述Android系统前台进程、可见进程、服务进程、后台进程和空进程的优先级排序原因', '0', '0', '0', '0', '      前台进程是Android系统中最重要的进程是与用户正在交互的进程所以被排放在首位可见进程和服务进程都是包含服务的进程不在前台与用户交互不响应界面时间的进程而是在后台长期运行所以他们被排放在前台进程之后而后台进程和空进程是不包含任何已经启动服务的进程在系统比较资', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('313', '2', '12', '简述Android系统的四种基本组件Activity、Service、BroadcaseReceiver和ContentProvider的用途', '0', '0', '0', '0', '      Activity是Android程序的呈现层显示可视化的用户界面并接收与用户交互所产生的界面事件用于提示用户程序已经正常启动。Service一般用于没有用户界面但需要长时间在后台运行的应用。BroadcaseReceiver是用来接受并响应广播消息的组件。ContentProvider是Android系统提供的一种标准的共享数据的机制应用程序可以通过ContentProvider访问其他应用程序的私有数据', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('314', '2', '12', '简述Activity事件回调函数的作用和调用顺序。', '0', '0', '0', '0', '      Activity事件回调函数具体分为Activity生命周期的事件回调函数和Activity状态保存和恢复函数的事件回调函数Activity生命周期的事件回调函数的作用主要是为了让Activity程序了解自身状态的变化Activity状态保存和恢复函数的事件回调函数的作用主要是保存或恢复Activity的状态信息。 Activity事件的调用顺序是    1onCreate,完全生命周期开始初始化 Activity     2onStart,可视生命周期开始对用户界面进行必要的更改    3onRestoreInstanceState,恢复onSaveLnstanceState保存的用户界面信息      4onResume,活动生命周期开始保存界面信息    5onSaveInstanceState,在 onResume后保存界面信息    6onRestart,重新进入可视生命周期前载入界面所需要的更改信息    7onPause,活动生命周期结束保存持久地数据或释放占用的资源    8onStop,可视生命周期结束保存持久地数据或释放占用的资源    9onDestory,完全生命周期结束释放资源 ', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('315', '2', '12', '简述6种界面布局的特点', '0', '0', '0', '0', '      6种界面布局分别为线性布局、框架布局、表格布局、相对布局、绝对布局和网格布局。 1线性布局的子元素可垂直或者水平排列但是每一列/行中只能有一个界面元素。  2框架布局是只存放一个元素的空白空间且位置只能是空白空间的左上角如果有多个子元素后放置的子元素会遮挡先放置的子元素。 3表格布局将屏幕划分网格把界面元素添加到网格中支持嵌套也可添加其他的界面布局。 4相对布局中的界面元素的位置是通过与其他的元素的相对位置确定的具有灵活性。 5绝对布局的界面元素的位置是通过坐标确定的他是不推荐使用的一种布局。 6网格布局将用户界面划分为网格界面元素可随意摆放在这些网格中界面元素可以占用多个网格的使界面设计更为灵活。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('316', '2', '12', '简述Android系统三种菜单的特点及其使用方式。', '0', '0', '0', '0', '      Android系统支持的三种菜单分别是选项菜单、子菜单和快捷菜单。  1选项菜单是常用的Android系统菜单可分为图标菜单和扩展菜单图标菜单的子项最多是六个支持显示图标不支持单选框和复选框而当子项多余六个时采用扩展菜单扩展菜单的子项是垂直排列支持单选框和复选框不支持显示图标。第一次启动选项菜单时只需要调用一次onCreateMenu函数。     2子菜单的表现形式是浮动窗体的形式适应小屏幕的显示形式能够展示更加详细的信息通过addSubMenu函数增加子菜单但不支持嵌套。在选项菜单和快捷菜单中使用子菜单便于显示和分类相似的菜单子项。     3快捷菜单采用动窗体的显示形式启动方式特别点击界面元素超过2秒后则启动该界面元素的快捷菜单。每次启动快捷菜单时都要调用一次onCreateMenu函数', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('317', '2', '12', '说明使用操作栏为程序开发所带来的便利', '0', '0', '0', '0', '      操作栏代替了传统的标题栏功能右侧用来显示“选项菜单”的菜单项但所显示的内容会根据操作栏所具有的空间不同而具有不同的现实方式。在屏幕尺寸较小的设备上操作栏会自动隐藏菜单项的文字而仅显示菜单项的图标而在屏幕尺寸较大的设备上操作栏会同时显示菜单项的文字和图标。操作栏提供多个实用的功能包括1将“选项菜单”的菜单项显示在操作栏的右侧2基于Fragment实现类似于Tab页的导航切换功能3为导航提供可“拖拽—放置”的下拉列表4可在操作栏上实现类似于“搜索框”的功能。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('318', '2', '12', '简述Intent的定义和用途', '0', '0', '0', '0', '      Intent是一个动作的完整描述包含了动作的产生组件、接收组件和传递的数据信息。Intent为Activity、Service和BroadcastReceiver等组件提供交互能力将一个组件的数据和动作传递给另一个组件。Intent的一个最常见的用途就是启动Activity和Service另一个用途是在Android系统上发布广播消息广播消息可以是接收到特定数据或消息也可以是手机的信号变化或电池的电量过低等信息', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('321', '2', '1', '请写一段程序实现冒泡排序法。', '0', '0', '0', '0', '      Public static maopao(int[] data){Public static maopao(int[] data){Public static maopao(int[] data){Public static maopao(int[] data){    Int temp;Int temp;Int temp;Int temp;    For(int i=0;i<data.lengthFor(int i=0;i<data.lengthFor(int i=0;i<data.lengthFor(int i=0;i<data.length----1;i++){1;i++){1;i++){1;i++){    For(int j=i+1;j<data.length;j++){For(int j=i+1;j<data.length;j++){For(int j=i+1;j<data.length;j++){For(int j=i+1;j<data.length;j++){    If(data[i]<data[j])If(data[i]<data[j])If(data[i]<data[j])If(data[i]<data[j])            Temp = data[i];Temp = data[i];Temp = data[i];Temp = data[i];    Data[i] = data[j];Data[i] = data[j];Data[i] = data[j];Data[i] = data[j];    Data[j] = temp;Data[j] = temp;Data[j] = temp;Data[j] = temp;    }}}}    }}}}    Return data;Return data;Return data;Return data;    }}}}', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('322', '2', '1', '请编程实现一个工厂模式', '0', '0', '0', '0', '        public class Factory{    public static Sample creator(int which){    if (which==1) return new SampleA();    else if (which==2)    return new SampleB();  }  } ', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('326', '2', '12', 'Android平台中实现对XML的三种解析方式及其各自特点。', '0', '0', '0', '0', '     第一种方式：DOM解析器，在内存中以树形结构存放，因此检索和更新效率会更高。但是对于特别大的文档，解析和加载整个文档将会很耗资源。第二种方式：SAX解析器,不用事先调用整个文档,解析速度快，占用内存少。第三种方式：PULL解析器：在PULL解析过程中返回的是数字，且我们需要自己获取产生的事件然后做相应的操作,小巧轻便，解析速度快，简单易用。', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('327', '2', '12', '简述Android应用怎样实现开机自起', '0', '0', '0', '0', '      监听一个开机启动的Broadcast,(android.intent.action.BOOT_COMPLETED)', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('328', '2', '12', 'ANR是什么，怎样尽量防止', '0', '0', '0', '0', '       Application Not Responding,运行在主线程里的任何方法都尽可能少做事情。特别是，Activity应该在它的关键生命周期方法（如onCreate()和onResume()）里尽可能少的去做创建操作。潜在的耗时操作，例如网络或数据库操作，或者高耗时的计算如改变位图尺寸，应该在子线程里（或者以数据库操作为例，通过异步请求的方式）来完成。然而，不是说你的主线程阻塞在那里等待子线程的完成——也不是调用Thread.wait()或是Thread.sleep()。替代的方法是，主线程应该为子线程提供一个Handler，以便完成时能够提交给主线程。以这种方式设计你的应用程序，将能保证你的主线程保持对输入的响应性并能避免由于5秒输入事件的超时引发的ANR对话框。这种做法应该在其它显示UI的线程里效仿，因为它们都受相同的超时影响。\r\n', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('4', '1', '1', 'java语言是1995年由（）公司发布的', 'Sun', 'Microsoft', 'Borland', 'Fox Software', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('5', '1', '1', '下列不是虚拟机执行过程特点的是', '双线程', '多线程', '动态链接', '异常处理', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('51', '1', '3', ' 下列不属于面向对象编程的三个特征的是', '封装', '指针操作', '多态性', '继承', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('52', '1', '3', '类所实现的接口以及修饰不可以是', 'public', 'abstract', ' final', ' void', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('53', '1', '3', '下列类的定义，错误的是', 'public class test extends Object{\r\n　　　……\r\n }', 'final class operators{\r\n　　　……\r\n　}', 'class Point{\r\n　　C.     class Point{\r\n　　　……\r\n  }', 'void class Point{\r\n　　　……\r\n  }', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('54', '1', '3', '关键字supper的作用是', '用来访问父类被隐藏的成员变量', '用来调用父类中被重载的方法', '用来调用父类的构造函数', ' 以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('55', '1', '3', '下面程序定义了一个类，关于该类说法正确的是\r\nabstract class abstractClass{\r\n　　　　……\r\n下面程序定义了一个类，关于该类说法正确的是\r\nabstract class abstractClass{\r\n　　　　……\r\n}\r\n　　　　……\r\n}', ' 该类能调用new abstractClass()，方法实例化为一个对象', '该类不能被继承', '该类的方法都不能被重载', ' 以上说法都不对', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('56', '1', '3', '关于对象的删除，下列说法正确的是', ' 必须由程序员完成对象的清除', ' java把没有引用的对象作为垃圾收集起来并释放', '只有当程序中调用System.gc()方法时才能进行垃圾收集', ' java中的对象都很小，一般不进行删除操作。', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('57', '1', '3', ' 下列说法正确的是', 'java中包的主要作用是实现跨平台功能', ' package语句只能放在import语句后面', '包（package）由一组类（class）和界面（interface）组成', '可以用#include关键词来标明来自其它包中的类', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('58', '1', '3', ' 关于构造方法，下列说法错误的是', '构造方法不可以进行方法重写', '构造方法用来初始化该类的一个新的对象', '构造方法具有和类名相同的名称', '构造方法不返回任何数据类型', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('59', '1', '4', '关于Applet运行过程，下列说法错误的是（）', '浏览器家在指定URL中的HTML文件', '浏览器加密HTML文件', '浏览器加载HTML文件中指定的Applet类', '浏览器中的java运行环境运行该Applet', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('6', '1', '1', 'java以JVM为基础，最下层是移植接口，由适配器和（）组成', '网卡', 'Java os', 'Java基本类', 'Java 应用程序和applet小程序', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('60', '1', '4', 'Applet的生命周期是指（）', 'Applet下载到浏览器，到用户连接到下一个页面的过程', '用户一次提交或刷新页面的全过程', 'Applet下载到浏览器，到用户退出浏览器的过程', '打开浏览器到关闭计算机的全过程', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('61', '1', '4', 'Applet是一个面板容器，它默认使用（）布局管理器', 'Border', 'Flow', 'Grid', 'Card', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('62', '1', '4', '与Applet生命周期有关的主要方法是()', 'init()', 'start()', 'stop()', '以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('63', '1', '4', '关于Applet和Application，下列说法错误的是（）', 'Applet自身不能运行', 'Applet可以嵌在Application中运行', 'Application以main()方法为入口', 'Applet可嵌在浏览器中运行', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('64', '1', '4', '在Applet中画图、画图像、显示字符串用到的方法是（）', 'paint()', 'init()', 'stop()', 'draw()', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('65', '1', '4', 'Graphics类中提供的绘图方法分为两类：一类是绘制图形，另一类是绘制（）', '屏幕', '文本', '颜色', '图像', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('66', '1', '4', '下列不属于Applet编写步骤的是（）', '引入需要的包和类', '定义一个Applet类的子类', '实现Applet类的某些方法', '加密Applet程序', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('67', '1', '4', '要在一个单一的类文件中创建既可以用作Java Applet，又可以用作Java应用程序的Java软件代码。下面说法错误的是（）', '作为Application要定义main()方法，并且把main()方法所在的类定义为一个public类', '为使该程序成为一个Applet，main()方法所在的这个public类必须继承Applet类或者Lapplet类', '在该类中可以像普通Applet类一样重写Applet类的init(),start(),paint()等方法', '转换后的程序只能在浏览器中加载执行，而不能在Appletviewer中执行。', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('68', '1', '4', '关于Applet和Application，下列说法错误的是（）', '是java的两种应用程序形式', 'Applet可以用Appletviewer或者浏览器加载执行', 'Applet不能利用java解释器从命令行启动运行', 'Applet和Application程序入口不一样', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('69', '1', '5', 'java中用来抛出异常的关键字是', 'try', 'catch', 'throw', 'finally', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('7', '1', '1', 'java程序的执行过程中用到一套JDK工具，其中javac.exe指', 'java语言编译器', 'java字节码解释器', 'java文档生成器', 'java类分解器', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('70', '1', '5', '关于异常，下列说法正确的是', '异常是一种对象', '一旦程序运行，异常将被创建', '为了保证程序运行速度，要尽量避免异常控制', '以上说法都不对', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('71', '1', '5', '（）类是所有异常类的父类。', 'Throwable', 'Error', 'Exception', 'AWTError', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('72', '1', '5', 'java语言中，下列哪一子句是异常处理的出口', 'try{…}子句', 'catch{…}子句', 'finally{…}子句', '以上说法都不对', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('73', '1', '6', 'Window是宣示屏上独立的本机窗口，它独立于其它容器，Window的两种形式是（）', 'Frame和Dialog', 'Panel和Frame', 'Container和Component', 'LayoutManager和Container', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('74', '1', '6', '框架（Frame）的缺省布局管理器就是（）', '流程布局（Flow Layout）', '卡布局（Card Layout）', '边框布局（Border Layout）', '网格布局（Grid Layout）', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('75', '1', '6', 'java.awt包提供了基本的java程序的GUI设计工具，包含控件、容器和（）', '布局管理器', '数据传送器', '图形和图像工具', '用户界面构', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('76', '1', '6', '所有Swing构件都实现了（）接口', 'ActionListener', 'Serializable', 'Accessible', 'MouseListener', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('77', '1', '6', '事件处理机制能够让图形界面响应用户的操作，主要包括（）', '事件', '事件处理', '事件源', '以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('78', '1', '6', 'Swing采用的设计规范是（）', '视图----模式----控制', '模式-----视图---控制', '控制-----模式----视图', '控制----视图-----模式', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('79', '1', '6', '抽象窗口工具包(  )是java提供的建立图形用户界面GUI的开发包.', 'AWT', 'Swing', 'Java.io', 'Java.lang ', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('8', '1', '1', 'java的API结构中，不属于类库主要包括的核心包的是', 'java包', 'javax', 'javadoc包', ' org扩展包', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('80', '1', '6', '关于使用Swing的基本规则,下列说法正确的是( )', 'Swing构件可直接添加到顶级容器中', '要尽量使用非Swing的重要级构件', 'Swing的Jbutton不能直接放到Frame上', '以上说法都对', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('81', '1', '6', '下列不属于java.event包中定义的事件适配器的是(  )', '构件适配器', '焦点适配器', '键盘适配器', '标签适配器', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('82', '1', '6', '(  )布局管理器使容器中各个构件呈网格布局，平均占据容器空间。', 'FlowLayout', 'BorderLayout', 'GridLayout', 'CardLayout', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('83', '1', '7', '线程调用了sleep（）方法后，该线程将进入（    ）状态。', '可运行状态', '运行状态', '阻塞状态', '终止状态', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('84', '1', '7', '关于java线程，下面说法错误的是（）', '线程是以CPU为主体的行为', 'java利用线程使整个系统成为异步', '创建线程的方法有两种：实现Runnable接口和继承Thread类', '新线程一旦被创建，它将自动开始运行', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('85', '1', '7', '在java中的线程模型包含（）', ' 一个虚拟处理器', 'CPU执行的代码', '代码操作的数据', '以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('86', '1', '7', '在java语言中，临界区可以是一个语句块，或者是一个方法，并用（）关键字标识', 'synchronized', 'include', 'import', 'Thread', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('87', '1', '7', '线程控制方法中，yield()的作用是（）', '返回当前线程的引用', '使比其低的优先级线程执行', ' 强行终止线程', '只让给同优先级线程运行', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('88', '1', '7', '线程同步中，对象的锁在（）情况下持有线程返回', ' 当synchronized()语句块执行完后', '当在synchronized()语句块执行中出现例外（exception）时', '当持有锁的线程调用该对象的wait()方法时', ' 以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('89', '1', '7', '在以下（）情况下，线程就进入可运行状态', '线程调用了sleep()方法时', '线程调用了join()方法时', '线程调用了yield()方法时', ' 以上都是', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('9', '1', '1', '每个java的编译单元可包含多个类或界面，但是每个编译单元最多只能有（）类或者界面是公共的', '一个', '两个', '四个', '任意多个', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('90', '1', '7', 'java用（）机制实现了进程之间的异步执行', '监视器', ' 虚拟机', '多个CPU', ' 异步调用', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('91', '1', '7', 'hread类的方法中，toString()方法的作用是（）', '只返回线程的名称', '返回当前线程所属的线程组的名称', '返回当前线程对象', '返回线程的名称', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('92', '1', '9', '流的传递方式是（）', '并行的', '串行的', '并行和串行', '以上都不对', '2', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('93', '1', '9', '下列不是java的输入输出流的是（）', '文本流', '字节流', '字符流', '文件流', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('94', '1', '9', '凡是从中央处理器流向外部设备的数据流称为（）', '文件流', '字符流', '输入流', '输出流', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('95', '1', '9', '获取一个不包含路径的文件名的方法为（）', ' String getName( )', 'String getPath( )', 'String getAbslutePath( )', 'String getParent( )', '1', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('96', '1', '9', '下列属于文件输入输出类的是（）', '　　FileInputStream和FileOutputStream', 'BufferInputStream和BufferOutputStream', 'PipedInputStream和PipedOutputStream', ' 以上都是', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('97', '1', '9', '下列不属于FileInputStream输入流的read（）成员函数的是（）', 'int read();', 'int read(byte b[]);', 'int read(byte b[],int offset,int len);', 'int read(int line);', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('98', '1', '9', '当处理的数据量很多，或向文件些很多次小数据，一般使用（）流', 'DataOutput', ' FileOutput', ' BufferedOutput', 'PipedOutput', '3', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('99', '1', '9', '当把一个程序、线程或代码段的输出连接到另一个程序、线程或代码短的输入时，应使用（）流', 'DataOutput', 'FileOutput', 'BufferedOutput', 'PipedOutput', '4', '0', '0', '0');
INSERT INTO `questionbank` VALUES ('f7ab236861ac11e8b2e50090f5d28238', '1', '2', '安卓是哪家公司的？', '百度', '谷歌', '微软', '亚马逊', '2', 'android 是 google的', '3c6e346e5b2111e8b2e50090f5d28238', '62457d6718bc4880bc949467c7cf9508');
INSERT INTO `questionbank` VALUES ('f7ab4ab661ac11e8b2e50090f5d28238', '1', '2', '安卓为什么不建议在主线程中访问远程接口', '不安全', '不知道', '防止阻塞', '快', '3', '防止阻塞', '3c6e346e5b2111e8b2e50090f5d28238', '62457d6718bc4880bc949467c7cf9508');
