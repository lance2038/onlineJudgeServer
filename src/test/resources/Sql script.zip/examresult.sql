/*
Navicat MySQL Data Transfer

Source Server         : lancedb
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : mysql

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2021-04-14 20:12:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `examresult`
-- ----------------------------
DROP TABLE IF EXISTS `examresult`;
CREATE TABLE `examresult` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `totalScore` int(11) NOT NULL DEFAULT '0',
  `dateTime` longtext NOT NULL,
  `useTime` longtext NOT NULL,
  `totalCount` int(11) NOT NULL,
  `wrongCount` int(11) NOT NULL,
  `rightCount` int(11) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of examresult
-- ----------------------------
